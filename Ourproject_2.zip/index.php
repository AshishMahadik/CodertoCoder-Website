<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>CTC</title>


<link rel="stylesheet" type="text/css" href="login.css">

</head>
<body>

<!-- header include -->
<?php include"header.php" ?>
<!-- end -->


<!-- First Section -->

<section class="container">
<div class="row_box">

    <div id="box_left_1" class="incol incol_left">

        <img src="images/CTCLogo.png" class="rounded sec1logo">
        <h1 class="meg_txt" style="padding-bottom: 3%;font-family: proxima-nova;">Coder Database</h1>
        <p class="reg_txt" style="font-weight: bold;">CTC is awesome platform for beginnerd & learners to learn and solve there problems relate to coding world.</p>

    </div>

    <div id="box_right_1" class="incol incol_right">
        
  
        <img class="sec1rigimg shadow-lg mb-5 bg-white rounded" src="images/Annotation.png" alt="Responsive image" width="90%">

                                  
    </div>

</div>            
</section>

<br>
<br>
<br>
<hr>



<!-- Second section -->

<section class="container">
<div id="carouselExampleIndicators" class="carousel slide carousel-fade" data-interval="false" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item mb-5 active">
    <div class="row">

        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="images/logo/cimg.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">C</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="#" class="btn btn_main btn-1 btncard">Details</a>
            </div>
        </div>
        </div>
        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="images/logo/cppimg.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">C++</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="#" class="btn btn_main btn-2 btncard">Details</a>
            </div>
        </div>
        </div>
    </div>             
    </div>
    <div class="carousel-item mb-5">
    <div class="row">

        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="images/logo/javaimg2.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">JAVA</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="#" class="btn btn_main btn-3 btncard">Details</a>
            </div>
        </div>
        </div>
        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="images/logo/htmlimg3.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">HTML</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="#" class="btn btn_main btn-1 btncard">Details</a>
            </div>
        </div>
        </div>
    </div>
    </div>
    <div class="carousel-item mb-5">
    <div class="row">

        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="images/logo/phpimg.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">PHP</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="#" class="btn btn_main btn-2 btncard">Details</a>
            </div>
        </div>
        </div>
        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="images/logo/cssimg.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">CSS</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="#" class="btn btn_main btn-3 btncard">Details</a>
            </div>
        </div> 
        </div>
    </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</section>
<br>
<hr>


<!-- Third Section -->

<section class="container mx-auto" id="s3">

<div id="carouselExampleControls" class="carousel slide carousel-fade mx-auto" data-interval="false" data-ride="carousel">
<div class="carousel-inner">
    
    <!-- Sign in Form Start -->

    <div class="container col-12  row_box carousel-item active" >
        <center>
        <div class="col-6 regright mx-auto">
            <img class="regimg" src="images/regimg.jpg" height="100%" width="100%">
        </div>
        
        <div class="col-6 regleft">
            <form action="insert.php" class="regform regcontent" method="post">
            <fieldset>    
              <div class="form-group">
                <input type="text" name="name" class="form-control" placeholder="Name" required>
              </div>  
              <div class="form-group">  
                <input type="email" name="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com" required>
              </div>  
              <div class="form-group">  
                <input type="text" name="profession" class="form-control" placeholder="Profession" required>
              </div>
              <div class="form-group">
                <select id="inputState" name="gender" class="form-control" placeholder="Gender" required>
                    <option selected>Gender...</option>
                    <option>Male</option>
                    <option>Female</option>
                    <option>Other</option>
                </select>
              </div>
              <div class="form-group">
                <input type="text" name="age" class="form-control" placeholder="Age" required>
              </div>
              <div class="form-group">
                <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password" required>
              </div>
              <div class="row">
                <div class="col">
                    <input type="submit" class="btn btn_main btn-2" value="Sign Up">
                </div>

                <div class="col">
                    <a class="btn btn_main btn-1" href="#carouselExampleControls" role="button" data-slide="prev" style="float: right;">Login</a>
                </div>
              </div>
            </fieldset>  
            </form>
        </div>
        </center>
    
    </div>  

    <!-- Sign in Form End -->



    <!-- Login Form Start -->

    <div class="container col-12 carousel-item" style="margin-top:10%;">
        <center>
        <div class="col-6 regright mx-auto">
            <img class="regimg2" align="middle" src="images/regimg.jpg" height="100%" width="100%">
        </div>
 
        <div class="col-6 regleft">
            <form action="export.php" class="regform regcontent" method="POST" ">
            

              <div class="form-group">  
                <input type="email" name="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com" required>
              </div>  

              <div class="form-group">
                <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password" required>
              </div>

              <div class="row">
                  <div class="col">
                    <input type="submit" class="btn btn_main btn-2" value="Login">
                  </div>


                  <div class="col">
                    <a class="btn btn_main btn-1" href="#carouselExampleControls" role="button" data-slide="prev" style="float: right;">Sign In</a>
                  </div>
              </div>
           
            </form>
            </div>
        </div>
        </center>
        
    </div>

    <!-- Login Form End -->

</div>
</div>
</section>
<br>
<hr>



<!-- footer include -->
<?php include"footer.php" ?>
<!-- end -->

</body>
</html>