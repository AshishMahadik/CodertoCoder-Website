<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html;charset=ISO-8859-1">

<link href="https://fonts.googleapis.com/css?family=Maven+Pro" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Tajawal" rel="stylesheet">

<script type = "text/javascript" src = "http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript">
$(function(){
  $('#c_req').bind('click', function(e) { 
      var url = $(this).attr('href'); //no need of this line
               
      //no need of this line
       // stop the browser from following the link

      //make ajax call
      $.ajax({
       type : "POST",
       url : "send-ajax.php" ,
       data: ({table: "c",id1: 1,id2: 2,id3: 2,id4: 0,id5: 2,id6: 0}),
       dataType : 'json',
       
       success: function(data) {
        $('#container1').html(data.message1);
        $('#container2').html(data.message2);
        $('#container3').html(data.message3);
        $('#container4').html(data.message13);
        $('#container5').html(data.message5);
        $('#container6').html(data.message6);
        $('#container7').html(data.message7);
        $('#container8').html(data.message8);
        
       } });
    });

  $('#cpp_req').bind('click', function() { 
      
               
      //no need of this line
       // stop the browser from following the link

      //make ajax call
      $.ajax({
       type : "POST",
       url : "send-ajax.php" ,
       data: ({table: "cpp",id1: 1,id2: 2,id3: 3,id4: 4,id5: 0,id6: 0}),
       dataType : 'json',
       
       success: function(data) {
        $('#container1').html(data.message1);
        $('#container2').html(data.message2);
        $('#container3').html(data.message3);
        $('#container4').html(data.message4);
        $('#container5').html(data.message5);
        $('#container6').html(data.message6);
        $('#container7').html(data.message7);
        $('#container8').html(data.message8);
        $('#container9').html(data.message9);
        $('#container10').html(data.message10);
        $('#container11').html(data.message11);
        $('#container12').html(data.message12);
       } });
    });

  $('#java_req').bind('click', function() { 
      
               
      //no need of this line
       // stop the browser from following the link

      //make ajax call
      $.ajax({
       type : "POST",
       url : "send-ajax.php" ,
       data: ({table: "java",id1: 1,id2: 0,id3: 0,id4: 0,id5: 2,id6: 2}),
       dataType : 'json',
       
       success: function(data) {
        $('#container1').html(data.message1);
        $('#container2').html(data.message2);
        $('#container3').html(data.message3);
        $('#container13').html(data.message13);
        $('#container14').html(data.message14);
        $('#container15').html(data.message15);
        $('#container16').html(data.message16);
        $('#container17').html(data.message17);
       } });
    });
   $('.call-c').bind('click', function() { 
      var data = $(this).data('params').split('|');
               
      //no need of this line
       // stop the browser from following the link

      //make ajax call
      $.ajax({
       type : "POST",
       url : "send-ajax.php" ,
       data: ({table: "c",id1: 0,id2: 0,id3: 0,id4: 0,id5: data[0] ,id6: data[1]}),
       dataType : 'json',
       
       success: function(data) {
        $('#container13').html(data.message13);
        $('#container14').html(data.message14);
        $('#container15').html(data.message15);
        $('#container16').html(data.message16);
        $('#container17').html(data.message17);
        $('#container18').html(data.message18);
      } });
    });
   $('.call-cpp').bind('click', function() { 
      var data = $(this).data('params').split('|');
               
      //no need of this line
       // stop the browser from following the link

      //make ajax call
      $.ajax({
       type : "POST",
       url : "send-ajax.php" ,
       data: ({table: "cpp",id1: 0,id2: 0,id3: 0,id4: 0,id5: data[0] ,id6: data[1]}),
       dataType : 'json',
       
       success: function(data) {
        $('#container13').html(data.message13);
        $('#container14').html(data.message14);
        $('#container15').html(data.message15);
        $('#container16').html(data.message16);
        $('#container17').html(data.message17);
        $('#container18').html(data.message18);
      } });
    });
   $('.call-java').bind('click', function() { 
      var data = $(this).data('params').split('|');
               
      //no need of this line
       // stop the browser from following the link

      //make ajax call
      $.ajax({
       type : "POST",
       url : "send-ajax.php" ,
       data: ({table: "java",id1: 0,id2: 0,id3: 0,id4: 0,id5: data[0] ,id6: data[1]}),
       dataType : 'json',
       
       success: function(data) {
        $('#container13').html(data.message13);
        $('#container14').html(data.message14);
        $('#container15').html(data.message15);
        $('#container16').html(data.message16);
        $('#container17').html(data.message17);
        $('#container18').html(data.message18);
      } });
    });
});
</script>
</head>

<body>
<?php include"header.php" ?>


<div id="pop-pop">


<section class="col-12 introhtml">
  <div class="container">
    <div class="introbox">
      <h1 id="container1" class="introtxt text-center" style="font-family: Raleway-Thin;"></h1>
      <h1 id="container2" class="introtxt text-center" style="font-family: CodeDemo-Bold;margin-top: 28px;"></h1>
      <h1 id="container3" class="introtxt text-center" style="font-family: Halfomania-Regular;"></h1>
    </div>
  </div>
</section>

<section class="container row_box">

  <div class="text-center">
  	<h1 id="container4" class="display-4 firsttxt" style="font-family: CodeDemo-Bold;"></h1>
  </div>
	
  <hr>

		<div class="col-12">
			<h1 id="container5" style="font-family: timeburnernormal;width: 800px;"></h1>
      <h4 id="container6" style="font-family: 'Maven Pro', sans-serif;"></h4>
      <ul id="container7" style="font-family: 'Tajawal', sans-serif;font-weight: bold;font-size: 20px;white-space: pre-line;"></ul>
      
    </div> 

    <center><div id="container8"></div></center>

  <hr>

		<div class="col-12">
			<h1 id="container9" style="font-family: timeburnernormal;width: 800px;"></h1>
			<h4 id="container10" style="font-family: 'Maven Pro', sans-serif;"></h4>
			<ul id="container11" style="font-family: 'Tajawal', sans-serif;font-weight: bold;font-size: 20px;white-space: pre-line;"></ul>
      <div id="container12"></div>
		</div>
		


</section>

</div>


<section class="container row_box" id="lop-lop">

  <hr>

  <div class="text-center">
    <h1 id="container13" class="display-4 firsttxt" style="font-family: CodeDemo-Bold;"></h1>
  </div>
  
  <hr>

  <div class="row">
      <h1 id="container14" style="font-family: timeburnernormal;width: 800px;"></h1>
      <h4 id="container15" style="font-family: 'Maven Pro', sans-serif;"></h4>
      <ul id="container16" style="font-family: 'Tajawal', sans-serif;font-weight: bold;font-size: 20px;white-space: pre-line;"></ul>
      <hr>
      <div id="container17"></div>
      <hr>
      <ul id="container18" style="font-family: 'Tajawal', sans-serif;font-weight: bold;font-size: 20px;white-space: pre-line;"></ul>
      <hr>
  </div>


</section>

<?php include"footer.php" ?>
<script type="text/javascript">
  
$('.call-java, .call-cpp, .call-c').click(function(){
  
  document.getElementById("pop-pop").style.display = "none";
  document.getElementById("lop-lop").style.display = "block";

}); 

$('#c_req,#cpp_req,#java_req').click(function(){
  
  document.getElementById("pop-pop").style.display = "block";

});  

</script>


</body>
</html>