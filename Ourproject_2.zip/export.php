<?php

session_start();


$con = mysqli_connect('localhost','root');
if($con) {
	echo"connection successful";
}
else{
	echo"no connection";
}
mysqli_select_db($con,'codertocoder');


$email = $_POST['email'];
$password = $_POST['password'];



$q = "SELECT  * FROM registration WHERE email='$email' && password = '$password' ";

$result = mysqli_query($con,$q);

$num = mysqli_num_rows($result);


if($num == 1)
{
	$_SESSION['email']  =  $email;
	$_SESSION['password']  =  $password;
	header('location:home.php');

}
else{
	header('location:index.php');
}
?>
