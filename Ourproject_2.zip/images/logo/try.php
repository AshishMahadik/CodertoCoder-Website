<!DOCTYPE html>
<!-- saved from url=(0028)http://localhost/Ourproject/ -->
<html class="gr__localhost"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>CTC</title>

<link rel="stylesheet" href="./try_files/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
<script src="./try_files/jquery-3.3.1.slim.min.js.download" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="./try_files/popper.min.js.download" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
<script src="./try_files/bootstrap.min.js.download" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

<link rel="stylesheet" type="text/css" href="./try_files/mainstyles.css">
<link rel="stylesheet" type="text/css" href="./try_files/login.css">

</head>
<body data-gr-c-s-loaded="true" style="">

<!-- header include -->






<header>

<nav class="navbar navbar-dark bg-dark">
  <a href="http://localhost/Ourproject/#" class="navbar-brand">
    <img src="./try_files/mlogo.png" class="img-fluid" alt="Responsive image">
  </a>
  <ul class="navbar-nav ml-auto">
    <li class="nav-item">
<button type="button" class="btn">
      
        <a href="http://localhost/Ourproject/#"><span>Home</span></a> 
 
</button>      
<button type="button" class="btn">
        <a href="http://localhost/Ourproject/#"><span>Community</span></a>
</button>
<button type="button" class="btn">
        <a href="http://localhost/Ourproject/#s3"><span>Login</span></a>
</button>
    </li>
  </ul>
</nav>







<div class="pos-f-t">
  <div class="collapse" id="navbarSupportedContent">
    <div class="navbar-dark bg-dark">
      <ul class="nav justify-content-end" style="color: #117bff;font-family: proxima-nova;">
        <li class="nav-item">
          <a class="nav-link active" href="http://localhost/Ourproject/#">About Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="http://localhost/Ourproject/#">Contact Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="http://localhost/Ourproject/#">Feedback</a>
        </li>
      </ul>
    </div>
  </div>
 </div> 
<nav class="navbar navbar-light bg-light">
  


  <button class="navbar-toggler togicon" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
  
  

    <ul class="nav m-auto intro">
    
    <li class="nav-item dropdown">
      <a class="nav-link" href="http://localhost/Ourproject/#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Introduction</a>
        </li> 

    <li class="nav-item dropdown">
      <a class="nav-link" href="http://localhost/Ourproject/#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">C</a>
          <div class="dropdown-menu animated" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="http://localhost/Ourproject/#">Action</a>
            <a class="dropdown-item" href="http://localhost/Ourproject/#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="http://localhost/Ourproject/#">Something else here</a>
          </div>
        </li>

    <li class="nav-item dropdown">    
      <a class="nav-link" href="http://localhost/Ourproject/#" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">C++</a>
          <div class="dropdown-menu animated" aria-labelledby="navbarDropdown2">
            <a class="dropdown-item href=" #"="">Action</a>
            <a class="dropdown-item" href="http://localhost/Ourproject/#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="http://localhost/Ourproject/#">Something else here</a>
          </div>
        </li>
        
    <li class="nav-item dropdown">    
      <a class="nav-link" href="http://localhost/Ourproject/#" id="navbarDropdown3" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">JAVA</a>
          <div class="dropdown-menu animated" aria-labelledby="navbarDropdown3">
            <a class="dropdown-item" href="http://localhost/Ourproject/#">Action</a>
            <a class="dropdown-item" href="http://localhost/Ourproject/#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="http://localhost/Ourproject/#">Something else here</a>
          </div>
        </li>    
</ul></nav>

</header>






<!-- First Section -->

<section class="container-fluid row_box">
<div class="col-12">

    <div id="box_right_1" class="incol incol_right">
        

        <center>
        <div class="sec1rigimg">  
        <img class="shadow-lg mb-5 bg-white rounded" src="./try_files/Annotation.png" alt="Responsive image" width="80%" height="80%">
        </div>
        </center>

                                  
    </div>

    <div id="box_left_1" class="incol incol_left">
        <div style="margin-left: 19vw;">
        <img src="./try_files/CTCLogo.png" class="rounded sec1logo">
        <h1 class="meg_txt" style="padding-bottom: 3%;font-family: proxima-nova;">Coder Database</h1>
        <p class="reg_txt" style="font-family: proxima-nova;">CTC is awesome platform for beginnerd &amp; learners to learn and solve there problems relate to coding world.</p>
        </div>
    </div>

</div>            
</section>

<hr>
<br>
<br>
<br>
<br>


<!-- Second section -->

<section class="container">
<div id="carouselExampleIndicators" class="carousel slide carousel-fade" data-interval="false" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item mb-5 active">
    <div class="row">

        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="./try_files/cimg.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">C</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="http://localhost/Ourproject/#" class="btn btn_main btn-1 btncard">Details</a>
            </div>
        </div>
        </div>
        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="./try_files/cppimg.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">C++</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="http://localhost/Ourproject/#" class="btn btn_main btn-2 btncard">Details</a>
            </div>
        </div>
        </div>
    </div>             
    </div>
    <div class="carousel-item mb-5">
    <div class="row">

        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="./try_files/javaimg2.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">JAVA</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="http://localhost/Ourproject/#" class="btn btn_main btn-3 btncard">Details</a>
            </div>
        </div>
        </div>
        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="./try_files/htmlimg3.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">HTML</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="http://localhost/Ourproject/#" class="btn btn_main btn-1 btncard">Details</a>
            </div>
        </div>
        </div>
    </div>
    </div>
    <div class="carousel-item mb-5">
    <div class="row">

        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="./try_files/phpimg.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">PHP</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="http://localhost/Ourproject/#" class="btn btn_main btn-2 btncard">Details</a>
            </div>
        </div>
        </div>
        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="./try_files/cssimg.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">CSS</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="http://localhost/Ourproject/#" class="btn btn_main btn-3 btncard">Details</a>
            </div>
        </div> 
        </div>
    </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="http://localhost/Ourproject/#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="http://localhost/Ourproject/#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</section>
<br>
<hr>


<!-- Third Section -->

<section class="container mx-auto" id="s3">

<div id="carouselExampleControls" class="carousel slide carousel-fade mx-auto" data-interval="false" data-ride="carousel">
<div class="carousel-inner">
    
    <!-- Sign in Form Start -->

    <div class="col-12  row_box carousel-item active">
        <center>
        <div class="regleft">
            <img class="regimg" src="./try_files/regimg.jpg" height="100%" width="100%">
        </div>
        </center>
        <div class="regright">
            <form action="http://localhost/Ourproject/insert.php" class="regform regcontent" method="post">
            <fieldset>    
              <div class="form-group">
                <input type="text" name="name" class="form-control" placeholder="Name" required="">
              </div>  
              <div class="form-group">  
                <input type="email" name="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com" required="">
              </div>  
              <div class="form-group">  
                <input type="text" name="profession" class="form-control" placeholder="Profession" required="">
              </div>
              <div class="form-group">
                <select id="inputState" name="gender" class="form-control" placeholder="Gender" required="">
                    <option selected="">Gender...</option>
                    <option>Male</option>
                    <option>Female</option>
                    <option>Other</option>
                </select>
              </div>
              <div class="form-group">
                <input type="text" name="age" class="form-control" placeholder="Age" required="">
              </div>
              <div class="form-group">
                <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password" required="">
              </div>
              <div class="row">
                <div class="col">
                    <input type="submit" class="btn btn_main btn-2" value="Sign Up">
                </div>

                <div class="col">
                    <a class="btn btn_main btn-1" href="http://localhost/Ourproject/#carouselExampleControls" role="button" data-slide="prev" style="float: right;">Login</a>
                </div>
              </div>
            </fieldset>  
            </form>
        </div>
    
    </div>  

    <!-- Sign in Form End -->



    <!-- Login Form Start -->

    <div class="col-12 row_box carousel-item" style="margin-top:10%;">
        <center>    
        <div class="regleft">
            <img class="regimg1" src="./try_files/regimg.jpg" height="100%" width="100%">
        </div>
        </center>
        <div class="regright">
            <form action="http://localhost/Ourproject/export.php" class="regcontent regform align-middle" method="POST" "="">
            

              <div class="form-group">  
                <input type="email" name="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com" required="">
              </div>  

              <div class="form-group">
                <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password" required="">
              </div>

              <div class="row">
                  <div class="col">
                    <input type="submit" class="btn btn_main btn-2" value="Login">
                  </div>


                  <div class="col">
                    <a class="btn btn_main btn-1" href="http://localhost/Ourproject/#carouselExampleControls" role="button" data-slide="prev" style="float: right;">Sign In</a>
                  </div>
              </div>
           
            </form>
            </div>
        </div>
        
    </div>

    <!-- Login Form End -->

</div>

</section>
<br>
<hr>



<!-- footer include -->




<!-- For Footer icons -->
<link rel="stylesheet" href="./try_files/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">



<footer class="footer-section">	

		<div class="container">
            <div class="col-12">
                <div class="footer-cta pt-5 pb-5">
                <div class="row">
                    <div class="col">
                        <div class="single-cta">
                            <i class="fas fa-phone"></i>
                            <div class="cta-text">
                                <h4>Call us</h4>
                                <span>7447590262</span>
                            </div>
                        </div>    
                    </div>
                    <div class="col">
                        <div class="single-cta">
                            <i class="far fa-envelope-open"></i>
                            <div class="cta-text">
                                <h4>Mail us</h4>
                                <span>codertocoder4@gmail.com</span>
                            </div>
                        </div>    
                    </div>
                </div>
                </div>
            </div>
            <div class="col-12 pt-5 pb-5">    
                <div class="row">
                    <div class="footpart">
                        <div class="footer-widget-left">
                            <div class="footer-logo">
                                <a href="http://localhost/Ourproject/index.html"><img src="./try_files/mlogo.png"></a>
                            </div>
                            <div class="footer-text">
                                <p>CTC is awesome platform for beginnerd &amp; learners to learn and solve there problems relate to coding world.</p>
                            </div>
                            <div class="footer-social-icon">
                                <span>Follow us</span>
                                <div class="row" style="margin-left: 0px;margin-right: 0px;">
                                <a href="https://www.facebook.com/Coder-To-Coder-758009907907223/">
                                <img src="./try_files/facebook.png">
                                </a>
                                <a href="https://twitter.com/ToCoder">
                                <img src="./try_files/twitter.png">
                                </a>
                                <a href="http://localhost/Ourproject/#"><img src="./try_files/instagram.png"></a>
                                </div>
                            </div>
                        </div>

                        <div class="footer-widget-right text-center">
                            <h3 style="color: #fff;">Useful Links</h3>
                            <ul style="display: contents;">
                                <li><a href="http://localhost/Ourproject/index.php">Home</a></li>
                                <li><a href="http://localhost/Ourproject/community.php">Community</a></li>
                                <li><a href="http://localhost/Ourproject/contactus.php">Contact US</a></li>
                                <li><a href="http://localhost/Ourproject/aboutus.php">About us</a></li>
                                <li><a href="http://localhost/Ourproject/login.php">Login</a></li>
                                <li><a href="http://localhost/Ourproject/signup.php">Sign Up</a></li>
                                <li><a href="http://localhost/Ourproject/feedback.php">FeedBack</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>    
        </div>
    <div class="copyright-area pt-3 pb-3">    
        <div class="container">
            <div class="row">
                <div class="col-6">
                    <div class="copyright-text">
                        <i>Copyright © 2019, All Right Reserved</i>
                    </div>    
                </div>
                <div class="col-6 d-lg-block text-right">
                    <div class="footer-menu">
                        <ul>
                            <li><a href="http://localhost/Ourproject/index.php">Home</a></li>
                            <li><a href="http://localhost/Ourproject/contactus.php">Contact</a></li>
                        </ul>
                    </div>    
                </div>
            </div>
        </div>
    </div>
</footer>






</body></html>