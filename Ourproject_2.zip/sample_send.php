<?php

include ('connection.php');
$row = mysqli_fetch_assoc( mysqli_query($connector,"SELECT * FROM cpp WHERE id = 3") );
$use = $row['img'];
echo '<img src="data:image/jpeg;base64,'.base64_encode( $use ).'"/>';
?>