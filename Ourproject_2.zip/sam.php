<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<img src="sample_send.php" width="175" height="200" />
</body>
</html>