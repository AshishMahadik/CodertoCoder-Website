<!DOCTYPE html>
<html>
<head>
<title>About Us</title>
<style>
{
  margin:0;
  padding:0;
  font-family: sans-serif; 
}

.team-section{
  overflow: hidden;
  text-align: center;
  padding: 0px;
}
.team-section h1{
  text-transform: uppercase;
  margin-bottom: 60px;
  color: black;
  font-size:40px;
}
.border{
  display: block;
  margin:auto;
  width: 160px;
  height: 3px;
  background: #3498db;
  margin-bottom:40px;
}
.ps{
  margin-bottom: 40px;
}
.ps  a{
  display: inline-block;
  margin:0 30px;
  width:160px;
  height: 160px;
  overflow: hidden;
  border-radius:50%;
}
.ps a img{
  width:100%; 
  filter: grayscale(100%);
  transition: 0.4s all;
}
.ps a:hover > img{
filter: none;
}
.section{
  width: 600px;
  margin:auto;
  font-size:20px;
  color: black;
  text-align:justify;
  height: 0;
  overflow: hidden;
}
.section:target{
  height:auto;
}
.names{
  display:block;
  margin-bottom: 30px;
  text-align: center;
  text-transform: uppercase;
  font-size: 22px;
}
</style>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

<link rel="stylesheet" type="text/css" href="">




</head>
<body>

<!-- header include -->
<?php include"header.php" ?>
<!-- end -->



<div class="team-section">
<h1>Our Team</h1>
<span class="border"></span>
<div class="ps">
  <a href="#p1"><img src="images/p1.jpg" alt=""></a>
  <a href="#p2"><img src="images/p2.jpg" alt=""></a>
  <a href="#p3"><img src="images/p3.jpg" alt=""></a>
  <a href="#p4"><img src="images/p4.jpg" alt=""></a>
</div>

<div class="section" id="p1">
  <span class="names">Vijay N. Sable</span>
  <span class="border"></span>
  <P>
    An ABIT satara alumnus and founder of CodertoCoder. He loves to solve programming problems in most efficient ways. Apart from CodertoCoder, he work as a software developer .
  </P>
</div>



<div class="section" id="p2">
  <span class="names">Ashish H. Mahadik</span>
  <span class="border"></span>
  <P>
    An ABIT satara alumnus and founder of CodertoCoder. He loves to solve programming problems in most efficient ways. Apart from CodertoCoder, he work as a software developer .
  </P>
</div>



<div class="section" id="p3">
  <span class="names">Avadhut R. Deshmukh</span>
  <span class="border"></span>
  <P>
    An ABIT satara alumnus and founder of CodertoCoder. He loves to solve programming problems in most efficient ways. Apart from CodertoCoder, he work as a software developer .
  </P>
</div>


<div class="section" id="p4">
  <span class="names">Aishwarya A. Kumbhar</span>
  <span class="border"></span>
  <P>
    An ABIT satara alumnus and founder of CodertoCoder. He loves to solve programming problems in most efficient ways. Apart from CodertoCoder, he work as a software developer .
  </P>
</div>

<!-- footer include -->
<?php include"footer.php" ?>
<!-- end -->


</body>
</html>