<head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

<script type = "text/javascript" src = "http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

<!-- For Footer icons -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="css/mainstyles.css">  
</head>

<body>


<nav class="navbar" style="background-color: black;">
  <a href="index.php" class="navbar-brand">
    <img src="images/mlogo.png" class="img-fluid" alt="Responsive image">
  </a>
  <ul class="navbar-nav ml-auto" style="font-family: CodeDemo-Bold;">
    <li class="nav-item">
        <button type="button" class="btn">
                <a href="index.php"><span>Home</span></a> 
        </button>      
        <button type="button" class="btn">
                <a href="comming.php"><span>Community</span></a>
        </button>
        <button type="button" class="btn">
                <a href="#s3"><span>Login</span></a>
        </button>
    </li>
  </ul>
</nav>







<header>
  <nav id="nav-container" class="navbar"  style="padding-bottom: 0;padding-top: 0;">
  
    <div class="toggle-icon" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="bar"></span><span class="bar"></span><span class="bar"></span></div>
  
    <ul class="nav m-auto intro">

        <li class="nav-item">
          <a value="2" class="nav-link mtxt" href="#" id="navbarDropdown">Introduction</a>
        </li> 

        <li class="nav-item megamenu-li">
            <a class="nav-link mtxt pp" href="#" id="c" >C</a>
        </li>

        <li class="nav-item megamenu-li">
            <a class="nav-link mtxt pp" href="#" id="cpp" >C++</a>
        </li>
       
        <li class="nav-item megamenu-li">
            <a class="nav-link mtxt" href="#" id="java" >JAVA</a>
        </li>

    </ul>

       
</nav>

<div class="pos-f-t">
  <div class="collapse" id="navbarSupportedContent">
      <ul class="nav justify-content-end togtxt" style="font-family: CodeDemo-Bold;">
        <li class="nav-item">
          <a class="nav-link" href="aboutus.php">About Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contact.php">Contact Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="feedback.php">Feedback</a>
        </li>
      </ul>
  </div>
</div> 










<!-- C slider menu start -->

<div class="menu_view vertical-menu-wrapper" id="menu1">
    
        <ul class="menu_content vertical-menu ul--reset">

            <img id="c_close" src="https://img.icons8.com/nolan/64/000000/delete-sign.png" href="#" style="float: right;">

            <h1 style="color: white;text-align: right;padding-bottom: 15px;">Menu</h1>
            
            <li class="menu_item vertical-menu-item">
            <a href="#" id="c_req" class="link--inverse-menu" data-vertical="1">C Introduction</a>
            </li>

            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="2">C Tutorial</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-c" data-params='2|2'>What is C?</a></li>
                    <li><a href="#" id="" class="call-c" data-params='3|3'>Character Set</a></li>
                    <li><a href="#" id="" class="call-c" data-params='3|4'>Tokens</a></li>
                    <li><a href="#" id="" class="call-c" data-params='3|5'>Constants</a></li>
                    <li><a href="#" id="" class="call-c" data-params='3|6'>Vriables</a></li>
                    <li><a href="#" id="" class="call-c" data-params='3|7'>Keywords</a></li>
                    <li><a href="#" id="" class="call-c" data-params='3|8'>Identifire</a></li>
                </ul>
            </li> <!-- item-has-children -->

            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="3">Operators</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-c" data-params='9|9'>Arithmetic Operator</a></li>
                    <li><a href="#" id="" class="call-c" data-params='9|10'>Relational Operator</a></li>
                    <li><a href="#" id="" class="call-c" data-params='9|11'>Logical Operator</a></li>
                    <li><a href="#" id="" class="call-c" data-params='9|12'>Assignment Operator</a></li>
                    <li><a href="#" id="" class="call-c" data-params='9|13'>Increment and Decrement Operator</a></li>
                    <li><a href="#" id="" class="call-c" data-params='9|14'>Conditional Operator</a></li>
                    <li><a href="#" id="" class="call-c" data-params='9|15'>Bitwise Operator</a></li>
                </ul>
            </li> <!-- item-has-children -->

           <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="4">Problem Solving Techniques</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-c" data-params='16|16'>Flowchart</a></li>
                    <li><a href="#" id="" class="call-c" data-params='16|17'>Algorithm</a></li>
                </ul>
            </li> <!-- item-has-children -->


            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu call-c" 
                data-params='18|18' data-vertical="5">Formatted Input</a>


            </li> <!-- item-has-children -->

            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu call-c" 
                data-params='19|19' data-vertical="6">Header Files</a>
            </li> <!-- item-has-children -->


            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="7">Decision Making And Branching Statement</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-c" data-params='20|20'>Simple if-Statement</a></li>
                    <li><a href="#" id="" class="call-c" data-params='20|21'>if-else Statement</a></li>
                    <li><a href="#" id="" class="call-c" data-params='20|22'>Nested if-else Statement</a></li>
                    <li><a href="#" id="" class="call-c" data-params='20|23'>Else-if ladder Statement</a></li>
                </ul>
            </li> <!-- item-has-children -->

            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="8">Control Statement</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-c" data-params='24|24'>While Statement</a></li>
                    <li><a href="#" id="" class="call-c" data-params='24|25'>do Statement</a></li>
                    <li><a href="#" id="" class="call-c" data-params='24|26'>do-while Statement</a></li>
                    <li><a href="#" id="" class="call-c" data-params='24|27'>for Statement</a></li>
                </ul>
            </li> <!-- item-has-children -->

            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="9">Array</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-c" data-params='28|28'>What is Array?</a></li>
                    <li><a href="#" id="" class="call-c" data-params='28|29'>Advantages And Disadvantages</a></li>
                </ul>
            </li> <!-- item-has-children -->


            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="10">Types Of Array</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-c" data-params='30|30'>One-Dimensional Array</a></li>
                    <li><a href="#" id="" class="call-c" data-params='30|31'>Two-Dimensional Array</a></li>
                </ul>
            </li> <!-- item-has-children -->            


            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="11">String</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-c" data-params='32|32'>Declaration Of String Varibles</a></li>
                    <li><a href="#" id="" class="call-c" data-params='32|33'>C Strings Initialization</a></li>
                    <li><a href="#" id="" class="call-c" data-params='32|34'>String Handling Function</a></li>
                </ul>
            </li> <!-- item-has-children -->            


            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="12">Recursion</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-c" data-params='35|35'>Call By Value</a></li>
                    <li><a href="#" id="" class="call-c" data-params='35|36'>Call By Reference</a></li>
                    </ul>
            </li> <!-- item-has-children --> 

            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="13">Structure</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-c" data-params='37|37'>Define Structure</a></li>
                    <li><a href="#" id="" class="call-c" data-params='37|38'>Initialization Of Structure</a></li>
                    <li><a href="#" id="" class="call-c" data-params='37|39'>Array Of Structure</a></li>
                </ul>
            </li> <!-- item-has-children --> 

            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="14">Function</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-c" data-params='40|40'>Need Of Function</a></li>
                    <li><a href="#" id="" class="call-c" data-params='40|41'>Advantages Of Function</a></li>
                    <li><a href="#" id="" class="call-c" data-params='40|42'>Function Defination</a></li>
                </ul>
            </li> <!-- item-has-children -->

            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu call-c"
                data-params='43|43' data-vertical="15">Storage Classes</a>
            </li> <!-- item-has-children -->           

            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="16">Pointers</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-c" data-params='44|44'>Declaring Pointers</a></li>
                    <li><a href="#" id="" class="call-c" data-params='44|45'>Accessing Pointers</a></li>
                    <li><a href="#" id="" class="call-c" data-params='44|46'>Pointers Arithmetic</a></li>
                    <li><a href="#" id="" class="call-c" data-params='44|47'>Array Of Pointers</a></li>
                </ul>
            </li> <!-- item-has-children -->


        </ul> <!-- cd-navigation -->
        <i class='active-marker'></i>  
</div>

<!-- ENd -->







<!-- Cpp slider menu start -->

<div class="menu_view vertical-menu-wrapper" id="menu2">
    
        <ul class="menu_content vertical-menu ul--reset">

            <img id="cpp_close" src="https://img.icons8.com/nolan/64/000000/delete-sign.png" href="#" style="float: right;">

            <h1 style="color: white;text-align: right;padding-bottom: 15px;">Menu</h1>

            <li class="menu_item vertical-menu-item">
            <a href="#" id="cpp_req" class="link--inverse-menu" data-vertical="1">C++ Introduction</a>
            </li>

            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="2">C++ Tutorial</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-cpp" data-params='3|3'>What is C++?</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='3|4'>Features Of C++</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='3|5'>Keywords</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='3|6'>Tokens</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='3|7'>Constants</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='3|8'>Basic Data types</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='3|9'>Identifires</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='3|10'>Structure of C++ program</a></li>
                </ul>
            </li> <!-- item-has-children -->

            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="2">Class and Objects</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-cpp" data-params='11|11'>Classes</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='11|12'>Access Specifiers</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='11|13'>C++ Object & Class</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='11|14'>Memory Allocation for objects</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="2">C++ Array</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-cpp" data-params='11|15'>C++ Array Description</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='11|17'>C++ Single Dimensional Array</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='11|18'>C++ Multidimensional Arrays</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='11|19'>Data members: Arrays</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='11|20'>Member Functions in C++</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='11|21'>Friend functions </a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="2">Constructor & Destructor</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-cpp" data-params='22|22'>constructor
                    </a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='22|23'>How constructor works?</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='22|24'>Types of constructor</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='22|26'>Constructor Overloading</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='22|27'>Destructor</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='22|28'>Inheritance</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='22|29'>Derived class</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='22|30'>Visibility modes</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='22|32'>Types  of Inheritance</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='22|33'>Virtual Base Class</a></li>
                </ul>
            </li> <!-- item-has-children -->


            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="2">Pointers</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-cpp" data-params='34|34'>C++ Pointers</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='34|35'>C++ Pointer to an Array</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='34|36'>Pointer to string</a></li>
                </ul>
            </li> <!-- item-has-children -->


            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="2">Polymorphism</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-cpp" data-params='37|37'>Polymorphism in C++
</a></li>
                    <li><a href="#" id="" class="call-cpp" data-params='37|38'>Types</a></li>
                </ul>
            </li> <!-- item-has-children -->


        </ul> <!-- cd-navigation -->
        <i class='active-marker'></i>  
</div>

<!-- ENd -->






<!-- JAVA slider menu start -->

<div class="menu_view vertical-menu-wrapper" id="menu3">
    
        <ul class="menu_content vertical-menu ul--reset">

            <img id="java_close" src="https://img.icons8.com/nolan/64/000000/delete-sign.png" href="#" style="float: right;">

            <h1 style="color: white;text-align: right;padding-bottom: 15px;">Menu</h1>
            
            <li class="menu_item vertical-menu-item">
            <a href="#" id="java_req" class="link--inverse-menu" data-vertical="1">Java Introduction</a>
            </li>


            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="2">Java Tutorial</a>
                <ul class="sub-menu">
                    <li><a href="#" id="" class="call-java" data-params='2|2'>What is Java</a></li>
                    <li><a href="#" id="" class="call-java" data-params='3|3'>JDK,JRE</a></li>
                    <li><a href="#" id="" class="call-java" data-params='3|4'>Java variables</a></li>
                    <li><a href="#" id="" class="call-java" data-params='3|5'>Data types</a></li>
                    <li><a href="#" id="" class="call-java" data-params='3|6'>Keywords</a></li>
                    <li><a href="#" id="" class="call-java" data-params='3|7'>Basic concept of OOP</a></li>
                </ul>
            </li> <!-- item-has-children -->

            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="3">Java Features</a>
                <ul class="sub-menu" id="sub-menu2">
                    <li><a href="#" id="" class="call-java" data-params='8|8'>Difference between Java & C</a></li>
                    <li><a href="#" id="" class="call-java" data-params='8|9'>Difference between Java & C++</a></li>
                </ul>
            </li> <!-- item-has-children -->

            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="4">Java Components</a>
                <ul class="sub-menu" id="sub-menu3">
                    <li><a href="#" id="" class="call-java" data-params='10|10'>Java Byte code & JVM</a></li>
                    <li><a href="#" id="" class="call-java" data-params='10|11'>Java Environment</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="5">Simple Java program</a>
                <ul class="sub-menu" id="sub-menu4">
                    <li><a href="#" id="" class="call-java" data-params='12|12'>Java program structure</a></li>
                    <li><a href="#" id="" class="call-java" data-params='12|13'>Implementing Java program</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="6">Operator</a>
                <ul class="sub-menu" id="sub-menu5">
                    <li><a href="#" id="" class="call-java" data-params='15|15'>Arithmetic Operator</a></li>
                    <li><a href="#" id="" class="call-java" data-params='15|16'>Relational Operator</a></li>
                    <li><a href="#" id="" class="call-java" data-params='15|17'>Logical Operator</a></li>
                    <li><a href="#" id="" class="call-java" data-params='15|18'>Assignment Operator</a></li>
                    <li><a href="#" id="" class="call-java" data-params='15|19'>Increment & Decrement Operator</a></li>
                    <li><a href="#" id="" class="call-java" data-params='15|20' class="call-cpp" data-params='8|8'>Conditional Operator</a></li>
                    <li><a href="#" id="" class="call-java" data-params='15|21'>Bitwise Operator</a></li>
                    <li><a href="#" id="" class="call-java" data-params='15|22'>Special Operator</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="7">Control Statements</a>
                <ul class="sub-menu" id="sub-menu6">
                    <li><a href="#" id="" class="call-java" data-params='23|23'>if-else</a></li>
                    <li><a href="#" id="" class="call-java" data-params='23|24'>switch</a></li>
                    <li><a href="#" id="" class="call-java" data-params='23|25'>for loop</a></li>
                    <li><a href="#" id="" class="call-java" data-params='23|26'>while loop</a></li>
                    <li><a href="#" id="" class="call-java" data-params='23|27'>do while loop</a></li>
                    <li><a href="#" id="" class="call-java" data-params='23|28'>break</a></li>
                    <li><a href="#" id="" class="call-java" data-params='23|29'>continue</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="8">visibility Control</a>
                <ul class="sub-menu" id="sub-menu7">
                    <li><a href="#" id="" class="call-java" data-params='30|30'>Public Access</a></li>
                    <li><a href="#" id="" class="call-java" data-params='30|33'>Protected Access</a></li>
                    <li><a href="#" id="" class="call-java" data-params='30|34'>Private Access</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="9">String</a>
                <ul class="sub-menu" id="sub-menu8">
                    <li><a href="#" id="" class="call-java" data-params='36|36'>String Arrays</a></li>
                    <li><a href="#" id="" class="call-java" data-params='36|37'>String Methods</a></li>
                    <li><a href="#" id="" class="call-java" data-params='36|38'>String Buffer Class</a></li>
                    <li><a href="#" id="" class="call-java" data-params='36|39'>String Buffer Constructor</a></li>
                    <li><a href="#" id="" class="call-java" data-params='36|40'>Vectors</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#"  class="link--inverse-menu" data-vertical="10">Packages</a>
                <ul class="sub-menu" id="sub-menu9">
                    <li><a href="#" id="" class="call-java" data-params='41|41'>Java API packages</a></li>
                    <li><a href="#" id="" class="call-java" data-params='41|42'>Creating packages</a></li>
                    <li><a href="#" id="" class="call-java" data-params='41|43'>Accessing a package</a></li>
                    <li><a href="#" id="" class="call-java" data-params='41|45'>Interface vs Abstract Class</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#" " class="link--inverse-menu" data-vertical="11">Multithreading</a>
                <ul class="sub-menu" id="sub-menu10">
                    <li><a href="#" id="" class="call-java" data-params='46|46'>Creating Thread</a></li>
                    <li><a href="#" id="" class="call-java" data-params='46|47'>Extending Thread class</a></li>
                    <li><a href="#" id="" class="call-java" data-params='46|48'>Implementing'Runnable' Interface</a></li>
                    <li><a href="#" id="" class="call-java" data-params='46|49'>Life cycle of a Thread</a></li>
                    <li><a href="#" id="" class="call-java" data-params='46|50'>Multithreaded program</a></li>
                    <li><a href="#" id="" class="call-java" data-params='46|51'>Thread Exception</a></li>
                    <li><a href="#" id="" class="call-java" data-params='46|52'>Thread priority</a></li>
                    <li><a href="#" id="" class="call-java" data-params='46|53'>Synchronization</a></li>
                    <li><a href="#" id="" class="call-java" data-params='46|54'>Deadlock</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#" " class="link--inverse-menu" data-vertical="12">Managing error & exceptions</a>
                <ul class="sub-menu" id="sub-menu11">
                    <li><a href="#" id="" class="call-java" data-params='55|55'>Type of error</a></li>
                    <li><a href="#" id="" class="call-java" data-params='55|56'>Exception</a></li>
                    <li><a href="#" id="" class="call-java" data-params='55|57'>Syntax of exception handling code</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#" " class="link--inverse-menu" data-vertical="13">Applet programming</a>
                <ul class="sub-menu" id="sub-menu12">
                    <li><a href="#" id="" class="call-java" data-params='58|58'>Applet Basic</a></li>
                    <li><a href="#" id="" class="call-java" data-params='58|59'>Local & Remote Applet</a></li>
                    <li><a href="#" id="" class="call-java" data-params='58|60'>Applet vs APplication</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#" " class="link--inverse-menu" data-vertical="14">Methods used in Applet</a>
                <ul class="sub-menu" id="sub-menu13">
                    <li><a href="#" id="" class="call-java" data-params='61|61'>Update() method</a></li>
                    <li><a href="#" id="" class="call-java" data-params='61|62'>Repaint() method</a></li>
                    <li><a href="#" id="" class="call-java" data-params='61|63'>Using font in Applet</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#" " class="link--inverse-menu" data-vertical="15">Graphics Programming</a>
                <ul class="sub-menu" id="sub-menu14">
                    <li><a href="#" id="" class="call-java" data-params='64|64'>Graphics class</a></li>
                    <li><a href="#" id="" class="call-java" data-params='64|65'>Line & Rectangle</a></li>
                    <li><a href="#" id="" class="call-java" data-params='64|66'>Circle & Ellipse</a></li>
                    <li><a href="#" id="" class="call-java" data-params='64|67'>Drawing arcs</a></li>
                    <li><a href="#" id="" class="call-java" data-params='64|68'>Drawing polygons</a></li>
                    <li><a href="#" id="" class="call-java" data-params='64|69'>Line Graphics</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#" " class="link--inverse-menu" data-vertical="16">Byte Stream Classes</a>
                <ul class="sub-menu" id="sub-menu15">
                    <li><a href="#" id="" class="call-java" data-params='70|70'>Input Stream class</a></li>
                    <li><a href="#" id="" class="call-java" data-params='70|71'>Output Stream class</a></li>
                </ul>
            </li>
            <li class="menu_item vertical-menu-item">
                <a href="#" " class="link--inverse-menu" data-vertical="16">Character Stream Classes</a>
                <ul class="sub-menu" id="sub-menu15">
                    <li><a href="#" id="" class="call-java" data-params='72|72'>Reader Stream class</a></li>
                    <li><a href="#" id="" class="call-java" data-params='72|73'>Writer Stream class</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#" " class="link--inverse-menu" data-vertical="17">Polymorphism</a>
                <ul class="sub-menu" id="sub-menu16">
                    <li><a href="#" id="" class="call-java" data-params='74|74'>Polymorphism</a></li>
                    <li><a href="#" id="" class="call-java" data-params='74|75'>Method Overoading</a></li>
                    <li><a href="#" id="" class="call-java" data-params='74|76'>Method Overriding</a></li>
                    <li><a href="#" id="" class="call-java" data-params='74|77'>Super Keyword</a></li>
                    <li><a href="#" id="" class="call-java" data-params='74|78'>Final Keyword</a></li>
                    <li><a href="#" id="" class="call-java" data-params='74|79'>Runtime polymorphism</a></li>
                    <li><a href="#" id="" class="call-java" data-params='74|80'>Dynamic binding</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#" " class="link--inverse-menu" data-vertical="18">Constructor</a>
                <ul class="sub-menu" id="sub-menu17">
                    <li><a href="#" id="" class="call-java" data-params='81|81'>Parametrized Constructor</a></li>
                    <li><a href="#" id="" class="call-java" data-params='81|82'>This Keyword</a></li>
                    <li><a href="#" id="" class="call-java" data-params='81|83'>Garbage collection</a></li>
                    <li><a href="#" id="" class="call-java" data-params='81|84'>Method Overloading</a></li>
                    <li><a href="#" id="" class="call-java" data-params='81|85'>Overloading Constructor</a></li>
                </ul>
            </li> <!-- item-has-children -->
            <li class="menu_item vertical-menu-item">
                <a href="#" " class="link--inverse-menu" data-vertical="19">Classes,Object & Methods</a>
                <ul class="sub-menu" id="sub-menu18">
                    <li><a href="#" id="" class="call-java" data-params='86|86'>Class Defination</a></li>
                    <li><a href="#" id="" class="call-java" data-params='86|87'>Creating Objects</a></li>
                    <li><a href="#" id="" class="call-java" data-params='86|88'>Array of Objects</a></li>
                </ul>
            </li> <!-- item-has-children -->
        </ul> <!-- cd-navigation -->
        <i class='active-marker'></i>  
</div>

<!-- ENd -->


</header>

<!-- script for sticky header -->

<script>
 $(document).ready(function () {
      $(window).on("scroll",function(){ 
      var scroll = $(window).scrollTop();
        
    
      if(scroll>=115){
        $("header").addClass('sticky');
      }else {
        $("header").removeClass('sticky');  
      }; 
      

    }); 
     
      
   });
</script>
<!-- END script for sticky header -->


<script>
  $(".toggle-icon").click(function() {
  $('#nav-container').toggleClass("pushed");
});
</script>







<!-- For C Slider Menu -->
<script>
$(function () {  

var path = window.location.pathname;
var page = path.split("/").pop();
console.log( page );

var c = document.getElementById("c");
var cpp = document.getElementById("cpp");
var java = document.getElementById("java");



$('#c,#c_close').bind('click', function() {
    if( page == "intro.php") {
    var element = document.getElementById("menu1"); 
   element.classList.toggle("menu");
    if ($("#menu2").hasClass("menu")) {
    var element = document.getElementById("menu2");    
    element.classList.toggle("menu");
    }
    else if ($("#menu3").hasClass("menu")) {
    var element = document.getElementById("menu3");    
    element.classList.toggle("menu");
    }
    }
    else {
   window.location = "intro.php";
    }
});

$('#cpp,#cpp_close').bind('click', function() {
    if( page == "intro.php") {
    var element = document.getElementById("menu2"); 
   element.classList.toggle("menu");
    if ($("#menu1").hasClass("menu")) {
    var element = document.getElementById("menu1");    
    element.classList.toggle("menu");
    }
    else if ($("#menu3").hasClass("menu")) {
    var element = document.getElementById("menu3");    
    element.classList.toggle("menu");
    }
    }
    else {
   window.location = "intro.php";
    }
});

$('#java,#java_close').bind('click', function() {
    if( page == "intro.php") {
    var element = document.getElementById("menu3"); 
   element.classList.toggle("menu");
    if ($("#menu1").hasClass("menu")) {
    var element = document.getElementById("menu1");    
    element.classList.toggle("menu");
    }
    else if ($("#menu2").hasClass("menu")) {
    var element = document.getElementById("menu2");    
    element.classList.toggle("menu");
    }
    }
    else {
   window.location = "intro.php";
    }
});
    

});
</script>
<!-- End For C Slider Menu -->

<script type="text/javascript">

$('.link--inverse-menu').click(function(e){
  e.preventDefault();
  
  var childUl = $(this).siblings("ul.sub-menu");
  
  if( childUl.hasClass('sub-menu-active') ){
    
    childUl.removeClass('sub-menu-active');
  } else {
    
    childUl.addClass('sub-menu-active');
  }
  
});  
</script>






<!-- For Slider Menu Inducter -->
<script type="text/javascript">
var getItemOffset = function getItemOffset(item) {
  return item.offsetTop;
};

var moveMarker = function moveMarker(offset) {
  var marker = document.querySelector('.active-marker');
  marker.style.transform = 'translateY(' + offset + 'px)';

};

var toggleActive = function toggleActive(e) {
  e.preventDefault();

  // Remove any existing active classes
  var links = document.querySelectorAll('.vertical-menu-item');
  links.forEach(function (link) {return link.classList.remove('is-active');});

  // Add class to active link
  var activeItem = e.target.parentElement;
  activeItem.classList.toggle('is-active');
  var offset = getItemOffset(activeItem);
  moveMarker(offset);
};

// Attach click event listener
var menu = document.querySelector('.vertical-menu');

menu.addEventListener('click', toggleActive); 
</script>
<!-- End For Slider Menu Inducter -->


</body>