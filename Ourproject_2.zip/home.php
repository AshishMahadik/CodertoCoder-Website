<?php 
session_start();
if(!isset($_SESSION['email'])){
    header('location:index.php');
}
?>



<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>CTC</title>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

<link rel="stylesheet" type="text/css" href="mainstyles.css">
<link rel="stylesheet" type="text/css" href="login.css">

</head>
<body>


<header>

<nav class="navbar navbar-dark bg-dark">
  <a href="#" class="navbar-brand">
    <img src="images/mlogo.png" class="img-fluid" alt="Responsive image">
  </a>
  <ul class="navbar-nav ml-auto">
    <li class="nav-item">
<button type="button" class="btn">
      
        <a href="#"><span>Home</span></a> 
 
</button>      
<button type="button" class="btn">
        <a href="#"><span>Community</span></a>
</button>
<button type="button" class="btn">
        <a href="logout.php"><span>Logout</span></a>
</button>
    </li>
  </ul>
</nav>







<div class="pos-f-t">
  <div class="collapse" id="navbarSupportedContent">
    <div class="navbar-dark bg-dark">
      <ul class="nav justify-content-end" style="color: #117bff;font-family: proxima-nova;">
        <li class="nav-item">
          <a class="nav-link active" href="#">About Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Contact Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Feedback</a>
        </li>
      </ul>
    </div>
  </div>
 </div> 
<nav class="navbar navbar-light bg-light">
  


  <button class="navbar-toggler togicon" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
  
  

    <ul class="nav m-auto intro">
    
    <li class="nav-item dropdown">
      <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Introduction</a>
        </li> 

    <li class="nav-item dropdown">
      <a class="nav-link" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">C</a>
          <div class="dropdown-menu animated" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="#">Action</a>
            <a class="dropdown-item"href="#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item"href="#">Something else here</a>
          </div>
        </li>

    <li class="nav-item dropdown">    
      <a class="nav-link" href="#" id="navbarDropdown2" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">C++</a>
          <div class="dropdown-menu animated" aria-labelledby="navbarDropdown2">
            <a class="dropdown-item href="#">Action</a>
            <a class="dropdown-item" href="#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Something else here</a>
          </div>
        </li>
        
    <li class="nav-item dropdown">    
      <a class="nav-link" href="#" id="navbarDropdown3" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">JAVA</a>
          <div class="dropdown-menu animated" aria-labelledby="navbarDropdown3">
            <a class="dropdown-item" href="#">Action</a>
            <a class="dropdown-item" href="#">Another action</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">Something else here</a>
          </div>
        </li> 
    </ul>       
</nav>

</header>


<!-- First Section -->

<section class="container-fluid row_box">
<div class="col-12">

    <div id="box_right_1" class="incol incol_right">
        

        <center>
        <div class="sec1rigimg">  
        <img class="shadow-lg mb-5 bg-white rounded" src="images/Annotation.png" alt="Responsive image" width="80%" height="80%">
        </div>
        </center>

                                  
    </div>

    <div id="box_left_1" class="incol incol_left">
        <div style="margin-left: 19vw;">
        <img src="images/CTCLogo.png" class="rounded sec1logo">
        <h1 class="meg_txt" style="padding-bottom: 3%;font-family: proxima-nova;">Coder Database</h1>
        <p class="reg_txt" style="font-family: proxima-nova;">CTC is awesome platform for beginnerd & learners to learn and solve there problems relate to coding world.</p>
        </div>
    </div>

</div>            
</section>

<hr>
<br>

<!-- Second section -->

<section class="container">
<div id="carouselExampleIndicators" class="carousel slide carousel-fade" data-interval="false" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item mb-5 active">
    <div class="row">

        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="images/logo/cimg.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">C</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="#" class="btn btn_main btn-1 btncard">Details</a>
            </div>
        </div>
        </div>
        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="images/logo/cppimg.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">C++</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="#" class="btn btn_main btn-2 btncard">Details</a>
            </div>
        </div>
        </div>
    </div>             
    </div>
    <div class="carousel-item mb-5">
    <div class="row">

        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="images/logo/javaimg2.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">JAVA</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="#" class="btn btn_main btn-3 btncard">Details</a>
            </div>
        </div>
        </div>
        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="images/logo/htmlimg3.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">HTML</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="#" class="btn btn_main btn-1 btncard">Details</a>
            </div>
        </div>
        </div>
    </div>
    </div>
    <div class="carousel-item mb-5">
    <div class="row">

        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="images/logo/phpimg.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">PHP</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="#" class="btn btn_main btn-2 btncard">Details</a>
            </div>
        </div>
        </div>
        <div class="col-xs-12 col-md-6 col-md-3">
        <div class="col card text-center">
            <img src="images/logo/cssimg.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">CSS</h5>
                <p class="card-text">Topics that brings you here.</p>
                <a href="#" class="btn btn_main btn-3 btncard">Details</a>
            </div>
        </div> 
        </div>
    </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</section>
<hr>







<!-- footer include -->
<?php include"footer.php" ?>
<!-- end -->

</body>
</html>