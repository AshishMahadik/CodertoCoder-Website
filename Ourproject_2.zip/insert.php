<?php

session_start();
header('location:index.php');

$con = mysqli_connect('localhost','root');
if($con) {
	echo"connection successful";
}
else{
	echo"no connection";
}
mysqli_select_db($con,'codertocoder');

$name = $_POST['name'];
$email = $_POST['email'];
$profession = $_POST['profession'];
$gender = $_POST['gender'];
$age = $_POST['age'];
$password = $_POST['password'];



$q = "SELECT  * FROM registration WHERE name = '$name' && email='$email' && profession='$profession' && gender = '$gender' && age = '$age' && password = '$password' ";

$result = mysqli_query($con,$q);

$num = mysqli_num_rows($result);


if($num == 1)
{
	echo "duplicate data";
}
else{
	$qy = "INSERT INTO registration(name , email , profession , gender , age , password) VALUES ('$name' , '$email' , '$profession' , '$gender' , '$age' , '$password')";
	mysqli_query($con,$qy);
}
?>
