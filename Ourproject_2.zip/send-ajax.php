<?php 
	include ('connection.php');

// For Intro pages

	$Answer = $_POST['table'];
	$userAnswer1 = $_POST['id1'];
	$row1 = mysqli_fetch_assoc( mysqli_query($connector,"SELECT * FROM $Answer WHERE id = $userAnswer1 ") );
	$first = $row1['title'];
    $fir = $row1['sub'];
    $f = $row1['detail'];

    $userAnswer2 = $_POST['id2'];
	$row2 = mysqli_fetch_assoc( mysqli_query($connector,"SELECT * FROM $Answer WHERE id = $userAnswer2 ") );
	$second = $row2['title'];


	$userAnswer3 = $_POST['id3'];
	$row3 = mysqli_fetch_assoc( mysqli_query($connector,"SELECT * FROM $Answer WHERE id = $userAnswer3 ") );
    $third = $row3['title'];
    $thir = $row3['sub'];
    $thi = $row3['detail'];
    $th = $row3['img'];

    $userAnswer4 = $_POST['id4'];
	$row4 = mysqli_fetch_assoc( mysqli_query($connector,"SELECT * FROM $Answer WHERE id = $userAnswer4 ") );
    $forth = $row4['title'];
    $fort = $row4['sub'];
    $for = $row4['detail'];
    $fo = $row4['img'];

 // End   

    // For pointes pages

    $userAnswer5 = $_POST['id5'];
	$row5 = mysqli_fetch_assoc( mysqli_query($connector,"SELECT * FROM $Answer WHERE id = $userAnswer5 ") );
	$fifth = $row5['head'];


	$userAnswer6 = $_POST['id6'];
	$row6 = mysqli_fetch_assoc( mysqli_query($connector,"SELECT * FROM $Answer WHERE id = $userAnswer6 ") );
    $sixth = $row6['title'];
    $sixt = $row6['sub'];
    $six = $row6['detail'];
    $si = $row6['img'];
    $s = $row6['program'];

    // End

	echo json_encode(array("message1" => "$first",  "message2" => "$fir",  "message3" => "$f",  "message4" => "$second",  "message5" => "$third",  "message6" => "$thir",  "message7" => "$thi", "message8" => '<img src="data:image/jpeg;base64,'.base64_encode( $th ).'" width=100px	/>',  "message9" => "$forth",  "message10" => "$fort",  "message11" => "$for", "message12" => '<img src="data:image/jpeg;base64,'.base64_encode( $fo ).'"/>',  "message13" => "$fifth",  "message14" => "$sixth",  "message15" => "$sixt",  "message16" => "$six", "message17" => '<img src="data:image/jpeg;base64,'.base64_encode( $si ).'" width=100%	/>', "message18" => "$s" )  );
	exit();
?>  