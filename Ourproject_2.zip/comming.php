<!DOCTYPE html>
<html>
<head>
<title>Thanks</title>
</head>
<body>
<?php include"header.php" ?>	
<div style="width: 100%;height: 500px;text-align: center;">
<a class="nav-link mtxt pp" href="#" id="cpp" style="font-size: 280px;">Comming Soon</a>
</div>
<?php include"footer.php" ?>
</body>
</html>