<?php

$username = "root";
$password = "";
$host = "localhost";

$connector = mysqli_connect('localhost','root','','codertocoder')
or die("Unable to connect");


?>