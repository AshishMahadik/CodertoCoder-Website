<footer class="footer-section">	

		<div class="container">
            <div class="col-12">
                <div class="footer-cta pt-5 pb-5">
                <div class="row">
                    <div class="col">
                        <div class="single-cta">
                            <i class="fas fa-phone"></i>
                            <div class="cta-text">
                                <h4>Call us</h4>
                                <span>7447590262</span>
                            </div>
                        </div>    
                    </div>
                    <div class="col">
                        <div class="single-cta">
                            <i class="far fa-envelope-open"></i>
                            <div class="cta-text">
                                <h4>Mail us</h4>
                                <span>codertocoder4@gmail.com</span>
                            </div>
                        </div>    
                    </div>
                </div>
                </div>
            </div>
            <div class="col-12 pt-5 pb-5">    
                <div class="row">
                    <div class="footpart">
                        <div class="footer-widget-left">
                            <div class="footer-logo">
                                <a href="index.html"><img src="images/mlogo.png"></a>
                            </div>
                            <div class="footer-text">
                                <p>CTC is awesome platform for beginnerd & learners to learn and solve there problems relate to coding world.</p>
                            </div>
                            <div class="footer-social-icon">
                                <span>Follow us</span>
                                <div class="row" style="margin-left: 0px;margin-right: 0px;">
                                <a href="https://www.facebook.com/Coder-To-Coder-758009907907223/">
                                <img src="images/logo/facebook.png">
                                </a>
                                <a href="https://twitter.com/ToCoder">
                                <img src="images/logo/twitter.png">
                                </a>
                                <a href="#"><img src="images/logo/instagram.png"></a>
                                </div>
                            </div>
                        </div>

                        <div class="footer-widget-right text-center">
                            <h3 style="color: #fff;">Useful Links</h3>
                            <ul style="display: contents;">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="comming.php">Community</a></li>
                                <li><a href="contact.php">Contact US</a></li>
                                <li><a href="aboutus.php">About us</a></li>
                                <li><a href="index.php">Login</a></li>
                                <li><a href="index.php">Sign Up</a></li>
                                <li><a href="feedback.php">FeedBack</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>    
        </div>
    <div class="copyright-area pt-3 pb-3">    
        <div class="container">
            <div class="row">
                <div class="col-6">
                    <div class="copyright-text">
                        <i>Copyright &copy; 2019, All Right Reserved</i>
                    </div>    
                </div>
                <div class="col-6 d-lg-block text-right">
                    <div class="footer-menu">
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="contact.php">Contact</a></li>
                        </ul>
                    </div>    
                </div>
            </div>
        </div>
    </div>
</footer>
